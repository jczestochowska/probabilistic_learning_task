CycleNo = 10; % it is equivalent to 30 trials, because single cycle contains random sequence of 3 trials
MinimumBlocks = 2;
MaximumBlocks = 4;
    


filename = input('Podaj nazw� pliku z raportem (bez rozszerzenia): ','s');

runtest(filename, CycleNo, MinimumBlocks, MaximumBlocks);